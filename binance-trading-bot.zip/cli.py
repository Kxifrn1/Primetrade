
import getpass
from bot import BasicBot

def run_cli():
    api_key = input("Enter your API Key: ")
    api_secret = getpass.getpass("Enter your API Secret (hidden): ")

    bot = BasicBot(api_key, api_secret)

    symbol = input("Enter symbol (e.g., BTCUSDT): ").upper()
    side = input("Enter side (BUY/SELL): ").upper()
    order_type = input("Enter order type (MARKET/LIMIT): ").upper()
    quantity = float(input("Enter quantity: "))

    price = None
    if order_type == "LIMIT":
        price = float(input("Enter limit price: "))

    bot.place_order(symbol, side, order_type, quantity, price)

if __name__ == "__main__":
    run_cli()
