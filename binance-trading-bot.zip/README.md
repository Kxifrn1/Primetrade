
# Binance Futures Testnet Trading Bot

This is a simplified Python trading bot for Binance Futures Testnet. It supports placing market and limit orders using the `python-binance` library.

## Features

- Place BUY/SELL market or limit orders
- CLI interface for user input
- Logging for API requests and errors

## Requirements

- Python 3.8+
- `python-binance`

## Setup

```bash
pip install -r requirements.txt
```

## Running the Bot

```bash
python cli.py
```

## Logging

All API actions and errors are logged to `bot.log`.
