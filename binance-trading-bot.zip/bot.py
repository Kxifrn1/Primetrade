
from binance.client import Client
import logging

class BasicBot:
    def __init__(self, api_key, api_secret, testnet=True):
        self.base_url = "https://testnet.binancefuture.com"
        self.client = Client(api_key, api_secret, testnet=testnet)
        self.client.FUTURES_URL = self.base_url
        self._setup_logger()

    def _setup_logger(self):
        logging.basicConfig(
            filename='bot.log',
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )

    def place_order(self, symbol, side, order_type, quantity, price=None):
        try:
            if order_type == "MARKET":
                order = self.client.futures_create_order(
                    symbol=symbol,
                    side=side,
                    type=order_type,
                    quantity=quantity
                )
            elif order_type == "LIMIT":
                order = self.client.futures_create_order(
                    symbol=symbol,
                    side=side,
                    type=order_type,
                    timeInForce="GTC",
                    quantity=quantity,
                    price=price
                )
            else:
                raise ValueError("Unsupported order type")

            logging.info(f"Order placed: {order}")
            print("Order executed:", order['orderId'])
            return order
        except Exception as e:
            logging.error(f"Error placing order: {e}")
            print("Error:", e)
            return None
